# CHANGELOG: jquery.breadcrumbs-generator

## v1.0.2
- All comments are written in English.
- Move plugin files to `dist/`.
- Not to generate JSDoc.

## v1.0.1
- Apply [pull request #1](https://github.com/sutara79/jquery.breadcrumbs-generator/pull/1)
